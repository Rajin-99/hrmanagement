package com.example.hr_management_rajin;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;

public class Admincontroller implements Initializable {
    public TableView<Admin> admintable;
    public TableColumn<Admin, Integer> id;
    public TableColumn<Admin, String> name;
    public TableColumn<Admin, String> email;
    public TableColumn<Admin, String> password;
    public TextField sid;
    public TextField sname;
    public TextField semail;
    public TextField spassword;

    @FXML
    private Label welcomeText;

    ObservableList<Admin> list = FXCollections.observableArrayList();

    @FXML
    protected void onHelloButtonClick() {
        fethdata();
    }

    private void fethdata() {
        list.clear();

        String jdbcUrl = "jdbc:mysql://localhost:3306/ hrmanagement";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "SELECT * FROM admin";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            // Populate the table with data from the database
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                String email = resultSet.getString("email");
                String password = resultSet.getString("password");
                admintable.getItems().add(new Admin(id, name, email, password));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        id.setCellValueFactory(new PropertyValueFactory<Admin, Integer>("id"));
        name.setCellValueFactory(new PropertyValueFactory<Admin, String>("name"));
        email.setCellValueFactory(new PropertyValueFactory<Admin, String>("email"));
        password.setCellValueFactory(new PropertyValueFactory<Admin, String>("password"));
        admintable.setItems(list);


    }

    public void InsertData(ActionEvent actionEvent) {


        String name = sname.getText();
        String email = semail.getText();
        String password = spassword.getText();


        String jdbcUrl = "jdbc:mysql://localhost:3306/hrmanagement";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "INSERT INTO `admin`( `name`, `email`, `password`) VALUES ('" + name + "','" + email + "','" + password + "')";
            Statement statement = connection.createStatement();
            statement.execute(query);
            // Populate the table with data from the database

        } catch (SQLException e) {
            e.printStackTrace();
        }


    }

    public void UpdateData(ActionEvent actionEvent) {
        String id = sid.getText();
        String name = sname.getText();
        String email = semail.getText();
        String password = spassword.getText();


        String jdbcUrl = "jdbc:mysql://localhost:3306/hrmanagement";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "UPDATE `admin` SET `name`='" + name + "',`email`='" + email + "',`password`='" + password + "' WHERE id='" + id + "' ";
            Statement statement = connection.createStatement();
            statement.execute(query);
            // Populate the table with data from the database

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void DeleteData(ActionEvent actionEvent) {

        String id = sid.getText();


        String jdbcUrl = "jdbc:mysql://localhost:3306/hrmanagement";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "DELETE FROM `admin` WHERE id='" + id + "'";
            Statement statement = connection.createStatement();
            statement.execute(query);
            // Populate the table with data from the database

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void LoadData(ActionEvent actionEvent) {

        String id = sid.getText();

        String jdbcUrl = "jdbc:mysql://localhost:3306/hrmanagement";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "SELECT * FROM admin WHERE id='" + id + "'";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            // Populate the table with data from the database
            while (resultSet.next()) {

                String name = resultSet.getString("name");
                String email = resultSet.getString("email");
                String password = resultSet.getString("password");

                sname.setText(name);
                semail.setText(email);
                spassword.setText(password);

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }



        }
}
