package com.example.hr_management_rajin;

import javafx.fxml.FXML;
import javafx.scene.control.Label;


import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.sql.*;

import java.io.IOException;

public class HelloController {
    public Button Button;
    public TextField email;
    public PasswordField password;

    @FXML
    private Label welcomeText;

    @FXML
    protected void onHelloButtonClick() {

        String semail = email.getText();
        String spassword = password.getText();
        String jdbcUrl = "jdbc:mysql://localhost:3306/hrmanagement";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "SELECT * FROM `logintable` WHERE  email='"+semail+"' AND password='"+spassword+"' ";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            // Populate the table with data from the database
            if (resultSet.next()) {

                try {

                    Parent secondScene = FXMLLoader.load(getClass().getResource("Dashboard.fxml"));

                    Stage secondStage = new Stage();
                    secondStage.setTitle("Dashboard Scene");
                    secondStage.setScene(new Scene(secondScene));

                    Stage firstSceneStage = (Stage) Button.getScene().getWindow();
                    firstSceneStage.close();



                    secondStage.show();
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }else{
                welcomeText.setText("Invalid Email Or Password");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }




    }
    public static int multiply(int a){
        int c=a*12;
        return c;
    }
}
